package siyam;


import java.util.Objects;

public class Circle { // değiken tanımları
    private Point center;
    private int radius;

    public Circle(){ // circle için set metodu
        this.setCenter(new Point());
        this.setRadius(0);
    }

    public Point getCenter() {

        return new Point(center);
    }

    public void setCenter(Point center) {
        new Point(center);
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) { // radius için set metodu
        if(radius<0){
            System.out.println("Please enter  a valid value");
        }
        else {
            this.radius = radius;
        }

    }

    public Circle(Circle copy){ // copy metodu

        Circle Newcircle = new Circle();

        Newcircle.center = copy.center;
        Newcircle.radius = copy.radius;
    }

    public Circle(int radius , Point center){
        this.radius = radius;
        this.center = center;
        }

    public String toString(){ // değerleri ekrana yazdıran fonksiyon
        return String.format("radius = %s Merkez = %s \nAlanı = %s" , this.radius , center.toString() , alan_hesapla());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Circle circle = (Circle) o;
        return radius == circle.radius && center.equals(circle.center);
    }

    @Override
    public int hashCode() {
        return Objects.hash(center, radius);
    }

    public double alan_hesapla(){
        return radius*radius*Math.PI;
    }
}
