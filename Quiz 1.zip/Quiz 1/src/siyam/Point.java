package siyam;

import java.util.Objects;

public class Point {
    private int X ;
    private int Y ;

    public Point(){
        this.setX(0);
        this.setY(0);

    }

    public Point(int X , int Y){
        this.setX(X);
        this.setY(Y);
    }

    public int getX() {
        return X;
    }

    public void setX(int x) {
        X = x;
    }

    public int getY() {
        return Y;
    }

    public void setY(int y) {
        Y = y;
    }

    public Point(Point copy){

        Point Newpoint = new Point();

        Newpoint.X = copy.X;
        Newpoint.Y = copy.Y;

    }

    public String  toString(){ // merkezi yazdıran toString metodu
        return String.format("[%d , %d]" , this.X , this.Y);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Point point = (Point) o;
        return X == point.X && Y == point.Y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(X, Y);
    }
}
