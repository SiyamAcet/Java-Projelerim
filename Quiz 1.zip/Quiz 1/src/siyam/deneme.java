package siyam;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class deneme {
    public static void main(String[]args){
        Scanner fileIn = null;

        try {// dosya okuma
            fileIn = new Scanner(new FileInputStream("girdiQuiz1.txt"));
        }
        catch (FileNotFoundException e){
            System.out.println("File not found");
            System.exit(0);
        }
        double max_area = 0.0;

        while (fileIn.hasNext()){ // satır satır dosya okuma
            int value_x = fileIn.nextInt();
            int value_y = fileIn.nextInt();
            int value_radius = fileIn.nextInt();
            Point point = new Point(value_x , value_y);
            Circle circle = new Circle(value_radius , point);
            System.out.println(circle.toString());
            System.out.println("");

            if(circle.alan_hesapla()>max_area){// max alan bulma 
                max_area = circle.alan_hesapla();
            }

        }
        System.out.printf("Max area :\n%.2f " , max_area);


    }
}
