
package quiz_3;

/**
 *
 * @author Siyam
 */

public class Item {
    private String itemID;
    private String itemName;


    // get ve set metotları
    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    // Constructor
    public Item(String itemID, String itemName) {
        this.itemID = itemID;
        this.itemName = itemName;
    }
    //toString metodu
    public String toString(){
        return String.format("Item ID :%s Item Name :%s",itemID,itemName);
    }
}
