
package quiz_3;

/**
 *
 * @author Siyam
 */
public class Quiz_3 {
    public static void main(String[] args){
        Stack stack = new Stack();
        Item item1 = new Item("111","Sultan Abdulhamit");
        Item item2 = new Item("222","Sarı Selim");
        Item item3 = new Item("333","Sultan Ibrahim");
        Item item4 = new Item("444","Hürrem Sultan");
        
        // push methodunun çağrılması
        stack.push(item1);
        stack.push(item2);
        stack.push(item3);
        stack.push(item4);

        // pop methodunun çağrılması
        stack.pop();
        stack.pop();
        stack.pop();
        stack.pop();
        
        System.out.println(stack.isEmpty());
    }

}
