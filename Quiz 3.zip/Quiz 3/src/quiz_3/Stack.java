
package quiz_3;

/**
 *
 * @author Siyam
 */
public class Stack {

    private int kapasite = 4;
    private Object[] dizi = new Object[kapasite];
    
    public Stack(){
        
    }

    //eleman sayısı 4 olan bir listeye max 4 tane obje eklemeye yarayan method
    public void push(Object object) {
        for (int i = 0; i < kapasite; ++i) {
            if (dizi[i] == null) {
                dizi[i] = object;
                return;
            }
        }
        System.out.println("Liste dolu");
    }
    //geriden gelen for döngüsü sayesinde sondaki elemanı sildirip yazdıran method
    public void pop(){
        for (int i = kapasite-1; i >= 0;--i){
            if (dizi[i]!=null){
                System.out.println("Silinen eleman : "+dizi[i]);
               dizi[i]=null;

               return;
            }
        }
        System.out.println("Silenecek eleman kalmadı");
    }
    // liste boş mu diye kontrol eden method
    public boolean isEmpty(){
        for (Object i: dizi){
            if (i!=null){
                return false;
            }
        }
        return true;

    }


}

