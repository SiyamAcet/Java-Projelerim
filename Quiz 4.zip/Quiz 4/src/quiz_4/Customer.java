
package quiz_4;

/**
 *
 * @author Siyam
 */

public class Customer {
    private int id;
    private String name;
    private Customer link;

    // dolu constructor
    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }
    // get ve set methotları
    public Customer getLink() {
        return link;
    }

    public void setLink(Customer link) {
        this.link = link;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // toString methodu
    @Override
    public String toString() {
        return "ID : " + id + "\nName : " + name;
    }
}

