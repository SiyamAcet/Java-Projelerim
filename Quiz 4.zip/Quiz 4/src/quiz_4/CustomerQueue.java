
package quiz_4;

/**
 *
 * @author Siyam
 */
public class CustomerQueue {
    private Customer front;
    private Customer back;

    // boş constructor
    public CustomerQueue(){
        front = null;
        back = null;
    }

    // Listeye ekleme yapan method
  public void add(Customer c){
      if (front==null){
          front = c;
          back = c;
      }
      else {
          back.setLink(c);
          back=c;
      }
  }

  // sondaki elemanı sildirip döndüren method
  public Customer remove(){
        if (front == null){
            System.out.println("Liste boş");
            return null;
        }
        else {

            Customer silinen =front;
            front = front.getLink();
            return silinen;
        }

  }

  // sırakini döndürme methodu
  public Customer peek() {
     return front;
  }

    // yazdırma methodu
    public void printElements(){
        Customer temp = front;
        while (temp != null){
            System.out.println(temp);
            temp = temp.getLink();
        }
        System.out.println("Liste boş");
    }

    // size methodu
    public int size(){
      int sayac = 0;
      Customer temp = front;
      while (temp != null){
          temp=temp.getLink();
          ++sayac;
      }
      return sayac;
    }

}
