
package quiz_4;

/**
 *
 * @author Siyam
 */
public class Quiz_4 {
   public static void main(String[] args) {

        Customer custumer = new Customer(23,"Siyam");
        Customer custumer1 = new Customer(78,"Özgür");
        Customer customer2 = new Customer(45,"Mustafa");

        CustomerQueue custumerQueue = new CustomerQueue();
        custumerQueue.add(custumer);
        custumerQueue.add(custumer1);
        custumerQueue.add(customer2);

        for (int i = 0 ; i<custumerQueue.size() ; ++i){
            custumerQueue.remove();
        }
        custumerQueue.printElements();

        Customer customer3 = new Customer(85,"Simge");
        Customer customer4 = new Customer(11,"Cenk");
        custumerQueue.add(customer3);
        custumerQueue.add(customer4);
        System.out.println(custumerQueue.peek());

    }
}
