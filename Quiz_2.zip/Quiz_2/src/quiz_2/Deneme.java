
package quiz_2;

/**
 *
 * @author Siyam
 */
public class Deneme {
     public static void main(String[] args){
         
        Person person = new Person("Siyam Acet");
        
        Truck truck = new Truck("Mercedes",6,person, 800.5 );

        System.out.println(truck.toString());

        Truck truck1 = new Truck(truck);

        // iki truck nesnesinin eşitliğini kontrol etme
        System.out.println(truck1.equals(truck));

    }
}
