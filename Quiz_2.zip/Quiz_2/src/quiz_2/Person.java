/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz_2;

/**
 *
 * @author Siyam
 */
public class Person {
        private String name;

    public Person(String name){
        this.name = name;
    }

    public Person(){
        name = null;
    }

    public Person(Person copy){
        this.name = copy.name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object otherobject){
        if (otherobject == null)
            return false;

        else if (getClass() != otherobject.getClass())
            return false;

        else {
            Person otherperson = (Person) otherobject;
            return (name.equals(otherperson.name));
        }
    }

    public String toString(){
        return String.format("Name : %s",name);
    }

    
}
