
package quiz_2;

/**
 *
 * @author Siyam
 */
public class Truck extends Vehicle {
    private double kapasite;

    public Truck(){
        super();
        setKapasite(0);
    }

    //dolu constructor
    public Truck(String marka, int silindir, Person owner ,double kapasite){
        super(marka , silindir , owner);
        this.setKapasite(kapasite);
    }

    // copy constructor
    public Truck(Truck copy){
        super(copy.getMarka(), copy.getSilindir(), copy.getOwner());
        this.setKapasite(copy.getKapasite());
    }

    public double getKapasite() {
        return kapasite;
    }

    public void setKapasite(double kapasite) {
        this.kapasite = kapasite;
    }

    //toString metodu
    public String toString(){
        return super.toString() + String.format("\nKapasite : %s" , kapasite);
    }


    // equals metodu
    public boolean equals(Object otherobject){
        if (otherobject == null)
            return false;

        else if (getClass() != otherobject.getClass())
            return false;

        else {
            Truck otherTruck = (Truck)otherobject;
            return (kapasite == otherTruck.kapasite);
        }

    }
}
