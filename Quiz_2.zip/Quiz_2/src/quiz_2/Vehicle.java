/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz_2;

/**
 *
 * @author Siyam
 */
public class Vehicle {
     private String marka;
    private int silindir;
    private  Person owner;

    public Vehicle(){
        this.setOwner(new Person());
        this.marka = null;
        this.setSilindir(0);
    }

    public Vehicle(String marka, int silindir, Person owner) {
        this.marka = marka;
        this.silindir = silindir;
        this.owner = owner;
    }

    public String getMarka() {
        return new String(marka);
    }

    public void setMarka(String marka) {
        this.marka = new String(marka);
    }

    public int getSilindir() {
        return silindir;
    }

    public void setSilindir(int silindir) {
        this.silindir = silindir;
    }

    public Person getOwner() {
        return new Person(owner);
    }

    public void setOwner(Person owner) {
        this.owner = new Person(owner);
    }

    public Vehicle(Vehicle copy){
        this.marka = copy.marka;
        this.silindir = copy.silindir;
        this.owner = copy.owner;
    }

    // toString metodu
    public String toString(){
        return String.format("Marka : %s \nSilindir : %d \nSahip : %s", this.marka, this.silindir, owner.getName());
    }

    // equals metodu
    public boolean equals(Object otherobject){
        if (otherobject == null)
            return false;

        else if (getClass() != otherobject.getClass())
            return false;

        else {
            Vehicle otherVehicle = (Vehicle) otherobject;
            return (marka.equals(otherVehicle.marka) && silindir == (otherVehicle.silindir) && owner.equals(otherVehicle.owner));
        }

    }
}
